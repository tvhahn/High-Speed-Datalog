import os
import sys
import json
import click
from HSD.HSDatalog import HSDatalog

def show_help(ctx, param, value):
    if value and not ctx.resilient_parsing:
        click.secho(ctx.get_help(), color=ctx.color)
        ctx.exit()

@click.command()
@click.argument('acq_folder', type=click.Path(exists=True))
@click.option('-s','--sensor_name', help="name of sensor - use \"all\" to extract all active sensors dataframes", default='')
@click.option('-ss','--sample_start', help="Sample Start", type=int, default=0)
@click.option('-se','--sample_end', help="Sample End", type=int, default=-1)
@click.option('-r','--raw_flag', is_flag=True, help="raw data flag (no sensitivity)", default=False)
@click.option('-l','--labeled', is_flag=True, help="use labels", default=False)
@click.option('-d','--debug', is_flag=True, help="debug timestamps", default=False)
@click.option("-h","--help", is_flag=True, is_eager=True, expose_value=False, callback=show_help, help="Show this message and exit.",)

def hsd_dataframe(acq_folder, sensor_name, sample_start, sample_end, raw_flag, labeled, debug):
    hsd = HSDatalog(acq_folder)

    def get_df_object(hsd, sensor, labeled):
        for ssd in sensor.sensor_descriptor.sub_sensor_descriptor:
            df = hsd.get_dataFrame(sensor.name,ssd.sensor_type, sample_start, sample_end, labeled = labeled, raw_flag= raw_flag)
            if not (df is None or df.empty):
                click.secho("\nDataFrame - Start sample: {}, End sample: {}\n{}".format(sample_start, len(df)-1 ,df), fg='cyan')

    hsd.enableTimestampRecovery(debug)

    df_flag = True
    while df_flag:
        if sensor_name == '':
            sensor = hsd.promptSensorSelect_CLI(hsd.getSensorList(only_active=True))
            if sensor is not None:
                get_df_object(hsd,sensor,labeled)
            else:
                break

        elif sensor_name == 'all':
            for sensor in hsd.getSensorList(only_active=True):
                get_df_object(hsd,sensor,labeled)
            df_flag = False
        
        else:
            sensor = hsd.getSensor(sensor_name)
            get_df_object(hsd,sensor,labeled)
            df_flag = False
 
if __name__ == '__main__':
    hsd_dataframe()

