import os
import sys
import json
import click
import numpy as np
from HSD.HSDatalog import HSDatalog

def show_help(ctx, param, value):
    if value and not ctx.resilient_parsing:
        click.secho(ctx.get_help(), color=ctx.color)
        ctx.exit()

@click.command()
@click.argument('acq_folder', type=click.Path(exists=True))
@click.option("-h","--help", is_flag=True, is_eager=True, expose_value=False, callback=show_help, help="Show this message and exit.",)

def hsd_dataframe(acq_folder):
    hsd = HSDatalog(acq_folder)

    def get_hsd_object(hsd, sensor):
        for ssd in sensor.sensor_descriptor.sub_sensor_descriptor:
            data, time = hsd.read_datalog(sensor.name,ssd.sensor_type, raw_flag = True)

            data = data.astype(np.int16).reshape(-1)

            x = data[0] + np.array([i for i in range(len(data))]).astype(np.int16)

            if (data == x).all():
                click.secho('{:>20} ({:<7}) : OK'.format(sensor.name, ssd.sensor_type), fg='green')
            else:
                click.secho('{:>20} ({:<7}) : ### ERRORS FOUND ###'.format(sensor.name, ssd.sensor_type), fg='red')

    for sensor in hsd.getSensorList(only_active=True):
        get_hsd_object(hsd,sensor)
 
if __name__ == '__main__':
    hsd_dataframe()

